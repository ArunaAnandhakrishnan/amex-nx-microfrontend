import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet } from '@angular/router';
import {
  AmexPageShellComponent,
  AmexTopNavBarComponent,
  AmexTabBarComponent,
  AmexTabItem
} from '@vn-core-ui-components/ui';

interface MenuItem {
  id: string;
  label: string;
  route: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    AmexPageShellComponent,
    AmexTopNavBarComponent,
    AmexTabBarComponent
  ],
  template: `
    <amex-page-shell
      portalStyle="onls"
      [showCustomHeader]="true"
      [showSidebar]="true">

      <div header>

        <amex-top-nav-bar
          portalStyle="onls"
          portalTitle="SOC ROC"
          [username]="'User'"
          (logout)="onLogout()">
        </amex-top-nav-bar>

        <amex-tab-bar
          portalStyle="onls"
          [tabs]="tabs"
          [activeTabId]="activeTabId"
          (tabClick)="onTabClick($event)">
        </amex-tab-bar>

        @if (activeTabId === 'masters' && showSubMenu) {
          <div class="soc-submenu">
            @for (sub of mastersSubItems; track sub.id) {
              <span class="soc-submenu-item" (click)="navigate(sub.route)">
                {{ sub.label }}
              </span>
            }
          </div>
        }

        @if (activeTabId === 'merchant-data' && showSubMenu) {
          <div class="soc-submenu">
            @for (sub of merchantSubItems; track sub.id) {
              <span class="soc-submenu-item" (click)="navigate(sub.route)">
                {{ sub.label }}
              </span>
            }
          </div>
        }

        @if (activeTabId === 'socs-rocs' && showSubMenu) {
          <div class="soc-submenu">
            @for (sub of socRocSubItems; track sub.id) {
              <span class="soc-submenu-item" (click)="navigate(sub.route)">
                {{ sub.label }}
              </span>
            }
          </div>
        }

        @if (activeTabId === 'utilities' && showSubMenu) {
          <div class="soc-submenu">
            @for (sub of utilitiesSubItems; track sub.id) {
              <span class="soc-submenu-item" (click)="navigate(sub.route)">
                {{ sub.label }}
              </span>
            }
          </div>
        }

        @if (activeTabId === 'reports' && showSubMenu) {
          <div class="soc-submenu">
            @for (sub of reportsSubItems; track sub.id) {
              <span class="soc-submenu-item" (click)="navigate(sub.route)">
                {{ sub.label }}
              </span>
            }
          </div>
        }

      </div>

      <router-outlet></router-outlet>

    </amex-page-shell>
  `,
  styles: [`
    .soc-submenu{
      background:#eef3f7;
      border-bottom:1px solid #d9d9d9;
      padding:12px 24px;
    }

    .soc-submenu-item{
      display:inline-block;
      margin-right:32px;
      cursor:pointer;
      color:#006fcf;
      font-size:13px;
    }

    .soc-submenu-item:hover{
      text-decoration:underline;
    }
  `]
})
export class AppComponent {

  activeTabId = 'masters';
  showSubMenu = false;

  tabs: AmexTabItem[] = [
    { id: 'masters', label: 'MASTERS' },
    { id: 'merchant-data', label: 'MERCHANT DATA' },
    { id: 'socs-rocs', label: "SOC'S & ROC'S" },
    { id: 'utilities', label: 'UTILITIES' },
    { id: 'reports', label: 'REPORTS' },
    { id: 'retrieval', label: 'RETRIEVAL' },
    { id: 'algeria-payment', label: 'ALGERIA PAYMENT' },
    { id: 'payment-register', label: 'PAYMENT REGISTER' }
  ];

  mastersSubItems: MenuItem[] = [
    {
      id: 'country-master',
      label: 'Country Master',
      route: '/masters/country-master'
    },
    {
      id: 'currency-master',
      label: 'Currency Master',
      route: '/masters/currency-master'
    }
  ];

  merchantSubItems: MenuItem[] = [
    {
      id: 'merchant-add',
      label: 'Add New',
      route: '/merchant-data/add'
    },
    {
      id: 'merchant-modify',
      label: 'Modify',
      route: '/merchant-data/modify'
    }
  ];

  socRocSubItems: MenuItem[] = [
    {
      id: 'soc-modify',
      label: 'Modify',
      route: '/soc-roc/modify'
    },
    {
      id: 'soc-delete',
      label: 'Delete',
      route: '/soc-roc/delete'
    },
    {
      id: 'print-soc',
      label: 'Print SOC',
      route: '/soc-roc/print-soc'
    },
    {
      id: 'list-roc',
      label: 'List ROCs based on reference number',
      route: '/soc-roc/list-roc'
    }
  ];

  utilitiesSubItems: MenuItem[] = [
    {
      id: 'file-upload',
      label: 'File Formation and Upload the Data',
      route: '/utilities/file-formation-upload'
    },
    {
      id: 'extract-rejected',
      label: 'Extract Rejected Items',
      route: '/utilities/extract-rejected-items'
    },
    {
      id: 'retrieval-old',
      label: 'Retrieval of Old Records and Reports',
      route: '/utilities/retrieval-old-records'
    }
  ];

  reportsSubItems: MenuItem[] = [
    {
      id: 'currency-report',
      label: 'Details by Currency',
      route: '/reports/details-by-currency'
    },
    {
      id: 'soc-control',
      label: 'SOC/Control Report',
      route: '/reports/soc-control-report'
    },
    {
      id: 'rejection-letter',
      label: 'Rejection Letter',
      route: '/reports/rejection-letter'
    },
    {
      id: 'rejection-details',
      label: 'Rejection Letter Details',
      route: '/reports/rejection-letter-details'
    },
    {
      id: 'consolidated',
      label: 'Consolidated Rejection Report',
      route: '/reports/consolidated-rejection-report'
    }
  ];

  constructor(private router: Router) { }

  navigate(route: string): void {
    this.router.navigateByUrl(route);
  }
  onTabClick(tabId: string): void {

    if (
      tabId === 'masters' ||
      tabId === 'merchant-data' ||
      tabId === 'socs-rocs' ||
      tabId === 'utilities' ||
      tabId === 'reports'
    ) {

      if (this.activeTabId === tabId) {
        this.showSubMenu = !this.showSubMenu;
      } else {
        this.activeTabId = tabId;
        this.showSubMenu = true;
      }

      return;
    }

    this.showSubMenu = false;
    this.activeTabId = tabId;

    const routeMap: Record<string, string> = {
      'retrieval': '/retrieval',
      'algeria-payment': '/algeria-payment',
      'payment-register': '/payment-register'
    };

    if (routeMap[tabId]) {
      this.router.navigateByUrl(routeMap[tabId]);
    }
  }


  onLogout(): void {
    console.log('logout');
  }
}