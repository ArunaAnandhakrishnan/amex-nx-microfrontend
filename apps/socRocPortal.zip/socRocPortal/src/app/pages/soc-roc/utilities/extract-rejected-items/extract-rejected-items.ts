import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-extract-rejected-items',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './extract-rejected-items.html',
  styleUrls: ['./extract-rejected-items.css']
})
export class ExtractRejectedItems {

  julianDay = '';
  captureDate = new Date();

  seNumber = '';
  seNumbers: string[] = [];

  includeSocHeader = true;

  addSeNumber(): void {

    const value = this.seNumber.trim();

    if (!value) {
      return;
    }

    if (!this.seNumbers.includes(value)) {
      this.seNumbers.push(value);
    }

    this.seNumber = '';
  }

  removeSelected(index: number): void {
    this.seNumbers.splice(index, 1);
  }

  doFileFormation(): void {
    console.log({
      julianDay: this.julianDay,
      captureDate: this.captureDate,
      seNumbers: this.seNumbers,
      includeSocHeader: this.includeSocHeader
    });
  }
}